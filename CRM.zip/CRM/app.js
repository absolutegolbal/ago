var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var session = require('express-session');
var multer = require ('multer');
var flash = require('express-flash');
const Auth = require("./middleware/auth");
const userAuth = require("./middleware/userauth");
var bodyParser = require("body-parser");
// const userAuth = require("./middleware/userAuth");

// admin routes
var indexRouter = require('./routes/index');
var dashboardRouter = require('./routes/dashboard');
var userdashboardRouter = require('./routes/userdashboard');

var addempRouter = require('./routes/addemp');
var leadsRouter = require('./routes/leads');
var viewempleadsRouter = require('./routes/viewempleads');
var viewempRouter = require('./routes/viewemp');
var newleadRouter = require('./routes/newlead');
var editleadRouter = require('./routes/editlead');
var editempRouter = require('./routes/editemp');
var loginRouter = require('./routes/login');
var errorRouter = require('./routes/error');

// var userAuthRouter = require('./middleware/userAuth');
var authRouter = require('./middleware/auth');
var userauthRouter = require('./middleware/userauth');


// employes routes
var thankyouRouter = require('./routes/thankyou');
// var pageNotFoundRouter = require('./routes/pageNotFound');
// var registerformRouter = require('./routes/registerform');


var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret : 'absoluego',
  cookie : {maxAge : 60000},
  saveUninitialized : false,
  resave : false
}));

app.use(flash());

// admin view
app.use('/', indexRouter);
app.use('/dashboard',Auth,dashboardRouter);
app.use('/userdashboard',userdashboardRouter);
app.use('/addemp',Auth, addempRouter);
app.use('/viewempleads',Auth,viewempleadsRouter);
app.use('/leads',userAuth,leadsRouter);
app.use('/viewemp',Auth, viewempRouter);
app.use('/thankyou', thankyouRouter);
app.use('/newlead',userAuth,newleadRouter);
app.use('/editlead',editleadRouter);
app.use('/editemp',editempRouter);
app.use('/error',errorRouter);



// app.use('/userAuth', authRouter);
app.use('/auth', authRouter);
app.use('/userauth', userauthRouter);
app.use('/login',loginRouter);

//employes view
// app.use('/pageNotFound',pageNotFoundRouter);



// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');

});

module.exports = app;
