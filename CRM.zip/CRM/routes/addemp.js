var express = require('express');
var router = express.Router();
var database = require('../database');
 

router.get("/", function (req, res, next) {
	if (req.session.loggedin) {

		var query = "SELECT * FROM users ";

		database.query(query, function (error, data) {

			if (error) {
				throw error;
			}
			else {
				res.render('addemp', { title: 'AGO Employees Information', action: 'list', users: data, message: req.flash('success') });
			}

		});
	} else {
		req.session.error = "You have to Login first";
		res.redirect('/login');
	}

});



router.post("/add_emp",  function (request, response, next) {

	
	var firstName = request.body.firstName;
	var lastName = request.body.lastName;
	var birthdayDate = request.body.birthdayDate;
	var emailAddress = request.body.emailAddress;
	var phoneNumber = request.body.phoneNumber;
	var user = request.body.user;
	var password = request.body.password;
	
	var query = `
	INSERT INTO users
	(firstName, lastName,birthdayDate,emailAddress, phoneNumber,user,password)
	VALUES ("${firstName}", "${lastName}", "${birthdayDate}", "${emailAddress}", "${phoneNumber}","${user}","${password}")
	`;

	database.query(query, function (error, data) {

		if (error) {
			throw error;
		}
		else {
			request.flash('success', 'user data Inserted');
			response.redirect("/addemp");
		}

	});

});


// Logout user
router.get('/logout', function (req, res) {
	req.session.destroy();
	res.redirect('/login');
});

module.exports = router;