var express = require('express');
var router = express.Router();
var database = require('../database');
 

router.get("/dashboard", function (request, response, next) {

	response.render("dashboard", { title: 'Insert Data into MySQL', action: 'add' });

});
router.get("/", function (req, res, next) {
	if (req.session.loggedin) {

		var query = "SELECT * FROM users ";

		database.query(query, function (error, data) {

			if (error) {
				throw error;
			}
			else {
				res.render('dashboard', { title: 'AGO Employees Information', action: 'list', users: data, message: req.flash('success') });
			}

		});
	} else {
		req.session.error = "You have to Login first";
		res.redirect('/login');
	}

});

// Logout user
router.get('/logout', function (req, res) {
	req.session.destroy();
	res.redirect('/login');
});

module.exports = router;