var express = require('express');

var router = express.Router();
var database = require('../database');


router.get('/edit/:id', function(request, response, next){

	var id = request.params.id;

	var query = `SELECT * FROM users WHERE id = "${id}"`;

	database.query(query, function(error, data){

		response.render('editemp', {title: 'Edit MySQL Table Data', action:'list', user:data});

	});

});

router.get('/delete/:id', function(request, response, next){

	var id = request.params.id; 

	var query = `
	DELETE FROM users WHERE id = "${id}"
	`;

	database.query(query, function(error, data){

		if(error)
		{
			throw error;
		}
		else
		{
			request.flash('success', 'user Data Deleted');
			response.redirect("/viewemp");
		}

	});

});


router.post('/edit/:id', function(request, response, next){

	var id = request.params.id;
	var firstName = request.body.firstName;
	var lastName = request.body.lastName;
	var email = request.body.email;
	var mobile = request.body.mobile;
	var address = request.body.address;
	var address2 = request.body.address2;
	var city = request.body.city;
	var state = request.body.state;
	var zip = request.body.zip;
	var Gender = request.body.gender;
	var taxammount = request.body.taxammount;
	var user = request.body.user;
	var comment = request.body.comment;
	var result = request.body.result;


	var query = `
	UPDATE leads 
	SET firstName = "${firstName}", 
	lastName = "${lastName}",
	email = "${email}", 
	mobile = "${mobile}", 
	address = "${address}" ,
	address2 = "${address2}", 
	city = "${city}", 
	state = "${state}" ,
	zip = "${zip}", 
	Gender = "${Gender}" ,
	taxammount = "${taxammount}", 
	user = "${user}" ,
	comment = "${comment}" ,
	result = "${result}" 
	WHERE id = "${id}"
	`;


	database.query(query, function(error, data){

		if(error)
		{
			throw error;
		}
		else
		{
			request.flash('success', 'user Data Updated');
			response.redirect('/viewempleads');
		}

	});

});

// Logout user
router.get('/logout', function (req, res) {
	req.session.destroy();
	res.redirect('/login');
});


module.exports = router;