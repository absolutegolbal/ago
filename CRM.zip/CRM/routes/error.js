var express = require('express');
var router = express.Router();
var database = require('../database');


/* GET home page. */
router.get('/', function(req, res, ) {
  res.render('error', { title: 'Absolute Global Oraganization' });
});

router.get('/error', function(req, res, ) {
  res.render('error', { title: 'Absolute Global Oraganization' });
});



module.exports = router;
