var express = require('express');

var router = express.Router();
var database = require('../database');




router.post("/", function (req, res, next) {
	// if (req.session.loggedin) {

	var user = req.body.user;

	var query = "SELECT * FROM leads WHERE user = ?";

	database.query(query, [user], function (error, data) {

		if (error) {
			throw error;
		}
		else {
			console.log(user);
			res.render('leads', { title: 'AGO Employees Information', action: 'list', users: data, message: req.flash('success') });
		}

	});
	// } else {
	// req.flash('success', 'Please login first!');
	// res.redirect('/userLogin');
	// }
});

// router.post("/", function (req, res, next) {

// 	var user = req.body.user;

// 	var query = "SELECT * FROM leads WHERE user = ?" ;

// 	database.query(query,[user], function (error, data) {

// 		if (error) {
// 			throw error;
// 		}
// 		else {
// 			res.render('leads', { title: 'AGO Employees Information', action: 'list', users: data, message: req.flash('success') });
// 		}

// 	});

// });

// Logout user
router.get('/logout', function (req, res) {
	req.session.destroy();
	res.redirect('/home');
});


module.exports = router;
