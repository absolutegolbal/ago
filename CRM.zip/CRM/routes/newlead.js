var express = require('express');

var router = express.Router();
var database = require('../database');


router.post("/", function(req, res, next){
	// if (req.session.loggedin) {

	var user = req.body.user;
	
	console.log(user);
	var query = "SELECT * FROM users WHERE user = ? " ;

	database.query(query, [user],function(error, data){

		if(error)
		{
			throw error; 
	}
		else
		{
			res.render('newlead', {title:'AGO Employees Information', action:'list', users:data, message:req.flash('success')});
		}

	});
// } else {
// req.flash('success', 'Please login first!');
// res.redirect('/userLogin');
// }
});


router.post("/new_lead",  function (request, response, next) {

	var date = new Date();
	var usaTime =  date.toLocaleString("en-US", {
                    timeZone: "America/New_York" 
                });
	var firstName = request.body.firstName;
	var lastName = request.body.lastName;
	var email = request.body.email;
	var mobile = request.body.mobile;
	var address = request.body.address;
	var address2 = request.body.address2;
	var city = request.body.city;
	var state = request.body.state;
	var zip = request.body.zip;
	var Gender = request.body.gender;
	var taxammount = request.body.taxammount;
	var user = request.body.user;
	var comment = "";
	var result= "";

	var query = `
	INSERT INTO leads
	(firstName, lastName,email,mobile, address, address2, city,state, zip, Gender,taxammount,user,comment,result,date)
	VALUES ("${firstName}", "${lastName}", "${email}", "${mobile}", "${address}", "${address2}","${city}","${state}", "${zip}", "${Gender}", "${taxammount}", "${user}", "${comment}", "${result}","${usaTime}")
	`;

	database.query(query, function (error, data) {

		if (error) {
			throw error;
		}
		else {
			request.flash('success', 'user data Inserted');
			response.redirect("/thankyou");
		}

	});
	

});


// Logout user
router.get('/logout', function (req, res) {
	req.session.destroy();
	res.redirect('/home');
});


module.exports = router;
