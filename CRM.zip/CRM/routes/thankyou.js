var express = require('express');
var router = express.Router();
var database = require('../database');


/* GET home page. */
router.get('/', function(req, res, ) {
  res.render('thankyou', { title: 'Absolute Global Oraganization' });
});

router.get('/thankyou', function(req, res, ) {
  res.render('thankyou', { title: 'Absolute Global Oraganization' });
});

// Logout user
router.get('/logout', function (req, res) {
	req.session.destroy();
	res.redirect('/login');
});

module.exports = router;
